<?php
include ('dbconfig.php');
 ?>
 <!doctype html>
 <html>
 <head>
<title>Hello Shop</title>
 </head>
 <body>
   <h1>Welcome to Hello Shop</h1>
   <?php
$qry = "SELECT * FROM products";
$result = mysqli_query($con,$qry);
if(mysqli_num_rows($result) == 0){
  echo "<p>No Products</p>";
}else{
echo "<table border = 1>";
  echo "<tr>
  <th> Products </th>
  <th> Price </th>
  </tr>";
$i = 1;
  while($data = mysqli_fetch_array($result)){
    echo "<tr>".

    "<td>".$i." " . $data['product_name'] .
    "</td>".
    "<td>" . $data['price'] . "</li></td>".
    "</tr>";
    $i++;
  }

echo "</table>";

}
    ?>
 </body>
 </html>
