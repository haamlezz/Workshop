<?php
$con = mysqli_connect("localhost","root","") or die("Error");

$db = mysqli_select_db($con,"laotop");
?>
